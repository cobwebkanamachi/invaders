#include "/usr/local/include/SDL3/SDL.h"
//#include <SDL.h>
#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#endif

#include <stdlib.h>
#include "/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix.h"
#include "invaders.h"

#define JOYSTICK_DEAD_ZONE 8000

#define FILE1 "/mnt/c/Users/user/Downloads/invaders/src/roms/invaders.h"
#define FILE2 "/mnt/c/Users/user/Downloads/invaders/src/roms/invaders.g"
#define FILE3 "/mnt/c/Users/user/Downloads/invaders/src/roms/invaders.f"
#define FILE4 "/mnt/c/Users/user/Downloads/invaders/src/roms/invaders.e"
#define FILE_TEST1 "roms/invaders_test_rom/Sitest_716.bin"
#define FILE_TEST2 "roms/test.h"

static SDL_Renderer* renderer = NULL;
static SDL_Texture* texture = NULL;
static SDL_Event e;

static invaders si;

static bool should_quit = false;
static int speed = 1;
static uint32_t current_time = 0;
static uint32_t last_time = 0;
static uint32_t dt = 0;
static char* pref_path = NULL;

#if 1
void dump_invaders(invaders* const si) {
    SDL_LogInfo(SDL_LOG_CATEGORY_APPLICATION, "--- CPU Dump ---");
    SDL_LogInfo(SDL_LOG_CATEGORY_APPLICATION, "PC: %04X  SP: %04X", si->cpu.pc, si->cpu.sp);

    // 一旦、確実に存在するレジスタだけに絞ります
    SDL_LogInfo(SDL_LOG_CATEGORY_APPLICATION, "A: %02X  B: %02X  C: %02X  D: %02X  E: %02X  H: %02X  L: %02X",
                si->cpu.a, si->cpu.b, si->cpu.c, si->cpu.d, si->cpu.e, si->cpu.h, si->cpu.l);

    // フラグは原因が判明するまで一旦非表示
    // SDL_LogInfo(SDL_LOG_CATEGORY_APPLICATION, "Flags: (Wait for definition)");
}
#else
void dump_invaders(invaders* const si) {
    SDL_LogInfo(SDL_LOG_CATEGORY_APPLICATION, "dump_invaders\n");
    SDL_LogInfo(SDL_LOG_CATEGORY_APPLICATION, "PC: %04X  SP: %04X\n", si->cpu.pc, si->cpu.sp);
    SDL_LogInfo(SDL_LOG_CATEGORY_APPLICATION, "A: %02X  BC: %02X%02X  DE: %02X%02X  HL: %02X%02X\n",
            si->cpu.a, si->cpu.b, si->cpu.c, si->cpu.d, si->cpu.e, si->cpu.h, si->cpu.l);
    // 修正版：フラグのダンプ部分
    SDL_LogInfo(SDL_LOG_CATEGORY_APPLICATION, "Flags (raw: %02X): S:%d Z:%d AC:%d P:%d CY:%d\n",
            si->cpu.f,
            (si->cpu.f >> 7) & 1, // Sign
            (si->cpu.f >> 6) & 1, // Zero
            (si->cpu.f >> 4) & 1, // Auxiliary Carry
            (si->cpu.f >> 2) & 1, // Parity
            (si->cpu.f >> 0) & 1  // Carry
    );
    SDL_LogInfo(SDL_LOG_CATEGORY_APPLICATION,"Port1: %X  Port2: %X\n", si->port1, si->port2);
}
#endif

#if 1
void update_screen(invaders* si) {
    void* pixels;
    int pitch;
    // SDL3: 成功時は true (0以外) を返すので注意
    if (SDL_LockTexture(texture, NULL, &pixels, &pitch)) {
        uint32_t* dst = (uint32_t*)pixels;

        for (int y = 0; y < SCREEN_HEIGHT; y++) {
            for (int x = 0; x < SCREEN_WIDTH; x++) {
                // screen_buffer[y][x] は [R, G, B, A] の並び
                uint8_t r = si->screen_buffer[y][x][0];
                uint8_t g = si->screen_buffer[y][x][1];
                uint8_t b = si->screen_buffer[y][x][2];

                // SDL_PIXELFORMAT_ARGB8888 の場合
                // 透明度(A)を 255 (不透明) に強制しつつ色を結合
                dst[y * (pitch / 4) + x] = (255 << 24) | (r << 16) | (g << 8) | b;
            }
        }
        SDL_UnlockTexture(texture);
    }
}
#else
static void update_screen(invaders* const si) {
  int pitch = 0;
  void* pixels = NULL;
  //SDL_LogInfo(SDL_LOG_CATEGORY_APPLICATION, "in update_screen\n");
  if (!SDL_LockTexture(texture, NULL, &pixels, &pitch)) {
    SDL_Log("Unable to lock texture: %s", SDL_GetError());
  } else {
    //SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255); // 黒色reset
    // VRAM（0x2400以降）に何かついてるか確認
    if (si->memory[0x2400] != 0) {
       SDL_Log("VRAM detected! Data: %02X", si->memory[0x2400]);
    }
#if 0
    if (si->memory[0x2400] != 0) {
        SDL_Log("VRAM has data! CPU is working.");
    }else{
        SDL_Log("VRAM has no data! CPU is not working");
    }
#endif
#if 0
    // 画面中央付近（0x3000あたり）にデータがあるか見る
    for (int i = 0x2400; i < 0x3FFF; i++) {
      if (si->memory[i] != 0) {
        SDL_Log("VRAM has data at %04X!", i);
        break;
      }
    }
#endif
    memset(pixels, 0xFF, 1000 * 4);
    //memcpy(pixels, si->screen_buffer, pitch * SCREEN_HEIGHT);
    //memset(pixels, 0xFF, pitch * SCREEN_HEIGHT);
    //((uint32_t*)pixels)[500] = 0xFF00FF00; // 強引に緑色のドットを1つ打つテスト
  }
  SDL_UnlockTexture(texture);
}
#endif

SDL_Joystick *joystick = NULL;
SDL_JoystickID *ids = NULL;

void mainloop(void) { 
  current_time = SDL_GetTicks();
  //SDL_LogInfo(SDL_LOG_CATEGORY_APPLICATION, "Main loop in: (time):%d\n",current_time);
  dt = current_time - last_time;

  while (SDL_PollEvent(&e) != 0) {
    //if (e.type == SDL_QUIT) {
    if (e.type == SDL_EVENT_QUIT) {
      should_quit = true;
#ifdef __EMSCRIPTEN__
      emscripten_cancel_main_loop();
#endif
    //} else if (e.type == SDL_KEYDOWN) {
    } else if (e.type == SDL_EVENT_KEY_DOWN) {
      SDL_Scancode key = e.key.scancode;
      SDL_LogInfo(SDL_LOG_CATEGORY_APPLICATION, "Main loop key down:%d",key);
      //SDL_Scancode key = e.key.keysym.scancode;
      //if (key == SDL_SCANCODE_C) {
      if (key == 6) { /*c key*/
        si.port1 |= 1 << 0; // coin
        SDL_LogInfo(SDL_LOG_CATEGORY_APPLICATION, "c pressed\n");
      } else if (key == 31){ /*SDL_SCANCODE_2) {*/
        si.port1 |= 1 << 1; // P2 start button
      } else if (key == 40){ /*SDL_SCANCODE_RETURN) {*/
        si.port1 |= 1 << 2; // P1 start button
      } else if (key == 44){ /*SDL_SCANCODE_SPACE) {*/
        SDL_LogInfo(SDL_LOG_CATEGORY_APPLICATION, "shoot button(space)\n");
        si.port1 |= 1 << 4; // P1 shoot button
        si.port2 |= 1 << 4; // P2 shoot button
      } else if (key == SDL_SCANCODE_LEFT) {
        si.port1 |= 1 << 5; // P1 joystick left
        si.port2 |= 1 << 5; // P2 joystick left
      } else if (key == SDL_SCANCODE_RIGHT) {
        si.port1 |= 1 << 6; // P1 joystick right
        si.port2 |= 1 << 6; // P2 joystick right
      } else if (key == SDL_SCANCODE_T) {
        si.port2 |= 1 << 2; // tilt
      } else if (key == SDL_SCANCODE_F9) { // to toggle between b&w / color
        si.colored_screen = !si.colored_screen;
      } else if (key == 41){ /*SDL_SCANCODE_ESCAPE) {*/
// allow web users to kill game with esc key
#ifdef __EMSCRIPTEN__
        SDL_Event quit_event;
        quit_event.type = SDL_EVENT_QUIT;
        //quit_event.type = SDL_QUIT;
        SDL_PushEvent(&quit_event);
#endif
      } else if (key == SDL_SCANCODE_TAB) {
        speed = 5;
      }
    //} else if (e.type == SDL_KEYUP) {
    } else if (e.type == SDL_EVENT_KEY_UP) {
      SDL_Scancode key = e.key.scancode;
      SDL_LogInfo(SDL_LOG_CATEGORY_APPLICATION, "Main loop key up:%d",key);
      //SDL_Scancode key = e.key.keysym.scancode;
      if (key == SDL_SCANCODE_C) {
        SDL_LogInfo(SDL_LOG_CATEGORY_APPLICATION, "Main loop key up 06(c)");
        si.port1 &= 0b11111110; // coin
      } else if (key == SDL_SCANCODE_2) {
        si.port1 &= 0b11111101; // P2 start button
      } else if (key == SDL_SCANCODE_RETURN) {
        si.port1 &= 0b11111011; // P1 start button
      } else if (key == SDL_SCANCODE_SPACE) {
        si.port1 &= 0b11101111; // P1 shoot button
        si.port2 &= 0b11101111; // P2 shoot button
      } else if (key == SDL_SCANCODE_LEFT) {
        si.port1 &= 0b11011111; // P1 joystick left
        si.port2 &= 0b11011111; // P2 joystick left
      } else if (key == SDL_SCANCODE_RIGHT) {
        si.port1 &= 0b10111111; // P1 joystick right
        si.port2 &= 0b10111111; // P2 joystick right
      } else if (key == SDL_SCANCODE_T) {
        si.port2 &= 0b11111011; // tilt
      } else if (key == SDL_SCANCODE_TAB) {
        speed = 1;
        // clear the queued audio to avoid audio delays
        // SDL_ClearQueuedAudio(audio_device); // @TODO
      }
    //} else if (e.type == SDL_JOYAXISMOTION) {
    } else if (e.type == SDL_EVENT_JOYSTICK_AXIS_MOTION) {
      SDL_LogInfo(SDL_LOG_CATEGORY_APPLICATION, "Main loop jaxis.value:%d",e.jaxis.value);
      if (e.jaxis.axis == 0) { // x axis
        if (e.jaxis.value < -JOYSTICK_DEAD_ZONE) {
          si.port1 |= 1 << 5; // P1 joystick left
          si.port2 |= 1 << 5; // P2 joystick left
        } else if (e.jaxis.value > JOYSTICK_DEAD_ZONE) {
          si.port1 |= 1 << 6; // P1 joystick right
          si.port2 |= 1 << 6; // P2 joystick right
        } else {
          si.port1 &= 0b11011111; // P1 joystick left
          si.port2 &= 0b11011111; // P2 joystick left

          si.port1 &= 0b10111111; // P1 joystick right
          si.port2 &= 0b10111111; // P2 joystick right
        }
      }
    //} else if (e.type == SDL_JOYBUTTONDOWN) {
    } else if (e.type == SDL_EVENT_JOYSTICK_BUTTON_DOWN) {
      if (e.jbutton.button == 1) { // B
        si.port1 |= 1 << 0; // coin
      } else if (e.jbutton.button == 0) {
        si.port1 |= 1 << 4; // P1 shoot button
        si.port2 |= 1 << 4; // P2 shoot button
      } else if (e.jbutton.button == 8) { // start
        si.port1 |= 1 << 2; // P1 start button
      } else if (e.jbutton.button == 9) { // select
        si.port1 |= 1 << 1; // P2 start button
      } else if (e.jbutton.button == 13) {
        si.port1 |= 1 << 5; // P1 joystick left
        si.port2 |= 1 << 5; // P2 joystick left
      } else if (e.jbutton.button == 14) {
        si.port1 |= 1 << 6; // P1 joystick right
        si.port2 |= 1 << 6; // P2 joystick right
      } else if (e.jbutton.button == 4) { // LB
        // to toggle between b&w / color
        si.colored_screen = !si.colored_screen;
      }
    //} else if (e.type == SDL_JOYBUTTONUP) {
    } else if (e.type == SDL_EVENT_JOYSTICK_BUTTON_UP) {
      if (e.jbutton.button == 1) { // B
        si.port1 &= 0b11111110; // coin
      } else if (e.jbutton.button == 0) {
        si.port1 &= 0b11101111; // P1 shoot button
        si.port2 &= 0b11101111; // P2 shoot button
      } else if (e.jbutton.button == 8) { // start
        si.port1 &= 0b11111011; // P1 start button
      } else if (e.jbutton.button == 9) { // select
        si.port1 &= 0b11111101; // P2 start button
      } else if (e.jbutton.button == 13) {
        si.port1 &= 0b11011111; // P1 joystick left
        si.port2 &= 0b11011111; // P2 joystick left
      } else if (e.jbutton.button == 14) {
        si.port1 &= 0b10111111; // P1 joystick right
        si.port2 &= 0b10111111; // P2 joystick right
      }
    }
  }

#if 0
  // mainループ内
  for(int i=0; i<100; i++) {
    i8080_step(&(si.cpu));
  }
  if (si.cpu.pc > 0) {
    SDL_Log("PC is moving! Current PC: %04X", si.cpu.pc);
  }
#endif
  //Test
  // mainループ内の invaders_update の前後あたり
  // 8080の命令 RST 1 (0xCF) と RST 2 (0xD7) を交互に投げる
  static double interrupt_timer = 0;
  interrupt_timer += dt;
  if (interrupt_timer >= 1.0 / 120.0) { // 120Hz相当（1フレームに2回割り込むため）
    static int next_interrupt = 0xcf;
    i8080_interrupt(&(si.cpu), next_interrupt);
    next_interrupt = (next_interrupt == 0xcf) ? 0xd7 : 0xcf;
    interrupt_timer = 0;
  }
  invaders_update(&si, dt * speed);
  //invaders_update(&si, dt);
  invaders_gpu_update(&si);
  si.update_screen(&si);
  //Test
  //SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255); // 赤色
  SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255); // black
  SDL_RenderClear(renderer);
  SDL_RenderTexture(renderer, texture, NULL, NULL);
  SDL_RenderPresent(renderer);

  last_time = current_time;
  dump_invaders(&si);
}

int main(void) {
  // SDL init
  if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_JOYSTICK)!=true) {
    SDL_Log("unable to initialize SDL: %s", SDL_GetError());
    return 1;
  }

  if (Sound_Init() == 0) {
    SDL_Log("Unable to initialise SDL_sound: %s", Sound_GetError());
    return 1;
  }

  if (NMIX_OpenAudio(NMIX_DEFAULT_DEVICE, NMIX_DEFAULT_FREQUENCY,
          NMIX_DEFAULT_SAMPLES) != 0) {
    SDL_Log("NMIX Error: %s\n", SDL_GetError());
    return -1;
  }
  NMIX_SetMasterGain(.5);

  // create SDL window
  SDL_Window* window = SDL_CreateWindow(
    "Space Invaders",
    SCREEN_WIDTH * 2,
    SCREEN_HEIGHT * 2,
    SDL_WINDOW_RESIZABLE
  );
  //SDL_Window* window = SDL_CreateWindow("Space Invaders",
  //    SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, SCREEN_WIDTH * 2,
  //    SCREEN_HEIGHT * 2, SDL_WINDOW_RESIZABLE );
      //SCREEN_HEIGHT * 2, SDL_WINDOW_RESIZABLE | SDL_WINDOW_ALLOW_HIGHDPI);

  if (window == NULL) {
    SDL_Log("unable to create window: %s", SDL_GetError());
    return 1;
  }

  SDL_SetWindowMinimumSize(window, SCREEN_WIDTH, SCREEN_HEIGHT);
  // SDL_ShowCursor(SDL_DISABLE);

  // create renderer
  renderer = SDL_CreateRenderer(window, NULL);
  //renderer = SDL_CreateRenderer(
  //    window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);

  if (renderer == NULL) {
    SDL_Log("unable to create renderer: %s", SDL_GetError());
    return 1;
  }

  SDL_SetRenderLogicalPresentation(renderer, SCREEN_WIDTH, SCREEN_HEIGHT,SDL_LOGICAL_PRESENTATION_LETTERBOX);

  // print info on renderer:
  //SDL_RendererInfo renderer_info;
  //SDL_GetRendererInfo(renderer, &renderer_info);
  SDL_Log("using renderer %s", SDL_GetRendererName(renderer));

  // create texture
  texture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA32,
      SDL_TEXTUREACCESS_STREAMING, SCREEN_WIDTH, SCREEN_HEIGHT);

  if (texture == NULL) {
    SDL_Log("unable to create texture: %s", SDL_GetError());
    return 1;
  }

  // Mine
  int count = 0;
  // ジョイスティックIDのリストを取得（同時に個数が count に入る）
  ids = SDL_GetJoysticks(&count);
  SDL_Log("接続されているジョイスティックの数: %d\n", count);
  if (ids && count > 0) {
    SDL_Log("接続されているジョイスティックの数: %d\n", count);
  }else{
    SDL_Log("ジョイスティックは接続されていません。\n");
  }
  // joystick init
  //SDL_Joystick* joystick = NULL;
  if (count > 0) {
  //if (SDL_NumJoysticks() > 0) {
    joystick = SDL_OpenJoystick(ids[0]);
    SDL_free(ids);
    if (joystick) {
      SDL_Log("opened joystick 0");
    } else {
      SDL_LogError(SDL_LOG_CATEGORY_ERROR, "opening joystick 0");
    }
  }

  // game init
  invaders_init(&si);
  si.update_screen = &update_screen;
  update_screen(&si);

  // loading roms
  if (invaders_load_rom(&si, FILE1, 0x0000) != 0) {
    return 1;
  }else{
    SDL_Log("FILE1 loaded\n");
  }
  if (invaders_load_rom(&si, FILE2, 0x0800) != 0) {
    return 1;
  }else{
    SDL_Log("FILE2 loaded\n");
  }
  if (invaders_load_rom(&si, FILE3, 0x1000) != 0) {
    return 1;
  }else{
    SDL_Log("FILE3 loaded\n");
  }
  if (invaders_load_rom(&si, FILE4, 0x1800) != 0) {
    return 1;
  }else{
    SDL_Log("FILE4 loaded\n");
  }

  char* savefile_path = NULL;
  char* base_path = SDL_GetPrefPath("cobweb", "invaders");

  if (base_path) {
    pref_path = base_path;
    size_t pref_path_len = SDL_strlen(pref_path);

    size_t savefile_path_len = pref_path_len + SDL_strlen("highscore.sav") + 1;
    savefile_path = malloc(savefile_path_len);
    if (savefile_path == NULL) {
      return 1;
    }

    SDL_snprintf(
        savefile_path, savefile_path_len, "%s%s", pref_path, "highscore.sav");
  }

  // load high scores
  SDL_IOStream* f = NULL;
  f = SDL_IOFromFile(savefile_path, "rb");
  if (f != NULL) {
    if (SDL_GetIOSize(f) != 2) {
      SDL_LogWarn(SDL_LOG_CATEGORY_APPLICATION, "Save file is corrupted");
    } else {
      uint8_t save[2] = {0, 0};
      size_t read = SDL_ReadIO(f, &save, 2); //ORG 1,2
      if (read == 2) {
        invaders_set_hiscore(&si, save);
        SDL_LogInfo(SDL_LOG_CATEGORY_APPLICATION, "Loaded highscore (%02X%02X)",
            save[0], save[1]);
      } else {
        SDL_LogWarn(SDL_LOG_CATEGORY_APPLICATION, "Failed to read save file");
      }
    }
    SDL_CloseIO(f);
  }
  f = NULL;

  // main loop
  //SDL_LogInfo(SDL_LOG_CATEGORY_APPLICATION, "Main loop 0:");
#ifdef __EMSCRIPTEN__
  emscripten_set_main_loop(mainloop, 0, 1);
#else
  while (!should_quit) {
    //SDL_LogInfo(SDL_LOG_CATEGORY_APPLICATION, "Main loop 1:");
    mainloop();
  }
#endif

  // save high scores
  uint8_t save[2] = {0, 0};
  invaders_get_hiscore(&si, save);

  f = SDL_IOFromFile(savefile_path, "wb");
  if (f != NULL) {
    size_t written = SDL_WriteIO(f, &save, 2); //ORG 1,2
    if (written == 2) {
      SDL_LogInfo(SDL_LOG_CATEGORY_APPLICATION, "Saved highscore (%02X%02X)",
          save[0], save[1]);
    } else {
      SDL_LogWarn(SDL_LOG_CATEGORY_APPLICATION, "Failed to write to save file");
    }
    SDL_CloseIO(f);
  }
  f = NULL;

  if (base_path) {
    SDL_free(base_path);
  }
  if (savefile_path) {
    SDL_free(savefile_path);
  }

  if (joystick) {
    SDL_CloseJoystick(joystick);
  }

  NMIX_CloseAudio();
  Sound_Quit();
  SDL_DestroyTexture(texture);
  SDL_DestroyRenderer(renderer);
  SDL_DestroyWindow(window);
  SDL_Quit();

  return 0;
}
