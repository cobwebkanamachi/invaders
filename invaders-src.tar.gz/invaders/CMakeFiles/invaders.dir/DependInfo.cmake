
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/mnt/c/Users/user/Downloads/invaders/deps/8080/i8080.c" "CMakeFiles/invaders.dir/deps/8080/i8080.c.o" "gcc" "CMakeFiles/invaders.dir/deps/8080/i8080.c.o.d"
  "/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix.c" "CMakeFiles/invaders.dir/deps/SDL_nmix/SDL_nmix.c.o" "gcc" "CMakeFiles/invaders.dir/deps/SDL_nmix/SDL_nmix.c.o.d"
  "/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix_file.c" "CMakeFiles/invaders.dir/deps/SDL_nmix/SDL_nmix_file.c.o" "gcc" "CMakeFiles/invaders.dir/deps/SDL_nmix/SDL_nmix_file.c.o.d"
  "/mnt/c/Users/user/Downloads/invaders/src/invaders.c" "CMakeFiles/invaders.dir/src/invaders.c.o" "gcc" "CMakeFiles/invaders.dir/src/invaders.c.o.d"
  "/mnt/c/Users/user/Downloads/invaders/src/main.c" "CMakeFiles/invaders.dir/src/main.c.o" "gcc" "CMakeFiles/invaders.dir/src/main.c.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
