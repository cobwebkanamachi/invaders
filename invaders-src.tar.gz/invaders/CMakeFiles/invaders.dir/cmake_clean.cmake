file(REMOVE_RECURSE
  "CMakeFiles/invaders.dir/deps/8080/i8080.c.o"
  "CMakeFiles/invaders.dir/deps/8080/i8080.c.o.d"
  "CMakeFiles/invaders.dir/deps/SDL_nmix/SDL_nmix.c.o"
  "CMakeFiles/invaders.dir/deps/SDL_nmix/SDL_nmix.c.o.d"
  "CMakeFiles/invaders.dir/deps/SDL_nmix/SDL_nmix_file.c.o"
  "CMakeFiles/invaders.dir/deps/SDL_nmix/SDL_nmix_file.c.o.d"
  "CMakeFiles/invaders.dir/src/invaders.c.o"
  "CMakeFiles/invaders.dir/src/invaders.c.o.d"
  "CMakeFiles/invaders.dir/src/main.c.o"
  "CMakeFiles/invaders.dir/src/main.c.o.d"
  "invaders"
  "invaders.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/invaders.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
