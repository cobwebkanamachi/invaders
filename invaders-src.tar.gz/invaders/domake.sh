cmake . -DROMS_DIR=.
