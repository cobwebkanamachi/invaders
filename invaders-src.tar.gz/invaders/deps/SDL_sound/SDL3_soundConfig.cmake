# sdl3_sound cmake project-config input


####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was SDL3_soundConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(FeatureSummary)
set_package_properties(SDL3_sound PROPERTIES
    URL "https://github.com/icculus/SDL_sound/"
    DESCRIPTION " An abstract soundfile decoder"
)

set(SDL3_sound_FOUND ON)

if(EXISTS "${CMAKE_CURRENT_LIST_DIR}/SDL3_sound-shared-targets.cmake")
    include("${CMAKE_CURRENT_LIST_DIR}/SDL3_sound-shared-targets.cmake")
    set(SDL3_sound_SDL3_sound_FOUND TRUE)
endif()

if(EXISTS "${CMAKE_CURRENT_LIST_DIR}/SDL3_sound-static-targets.cmake")
    include("${CMAKE_CURRENT_LIST_DIR}/SDL3_sound-static-targets.cmake")
    set(SDL3_sound_SDL3_sound-static_FOUND TRUE)
endif()

check_required_components(SDL3_sound)

function(_sdl_create_target_alias_compat NEW_TARGET TARGET)
  if(CMAKE_VERSION VERSION_LESS "3.18")
    # Aliasing local targets is not supported on CMake < 3.18, so make it global.
    add_library(${NEW_TARGET} INTERFACE IMPORTED)
    set_target_properties(${NEW_TARGET} PROPERTIES INTERFACE_LINK_LIBRARIES "${TARGET}")
  else()
    add_library(${NEW_TARGET} ALIAS ${TARGET})
  endif()
endfunction()

# Make sure SDL3_sound::SDL3_sound always exists
if(NOT TARGET SDL3_sound::SDL3_sound)
  if(TARGET SDL3_sound::SDL3_sound-shared)
    _sdl_create_target_alias_compat(SDL3_sound::SDL3_sound SDL3_sound::SDL3_sound-shared)
  elseif(TARGET SDL3_sound::SDL3_sound-static)
    _sdl_create_target_alias_compat(SDL3_sound::SDL3_sound SDL3_sound::SDL3_sound-static)
  endif()
endif()
