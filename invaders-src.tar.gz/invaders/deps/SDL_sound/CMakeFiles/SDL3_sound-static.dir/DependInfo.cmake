
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/mnt/c/Users/user/Downloads/invaders/deps/SDL_sound/src/SDL_sound.c" "deps/SDL_sound/CMakeFiles/SDL3_sound-static.dir/src/SDL_sound.c.o" "gcc" "deps/SDL_sound/CMakeFiles/SDL3_sound-static.dir/src/SDL_sound.c.o.d"
  "/mnt/c/Users/user/Downloads/invaders/deps/SDL_sound/src/SDL_sound_aiff.c" "deps/SDL_sound/CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_aiff.c.o" "gcc" "deps/SDL_sound/CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_aiff.c.o.d"
  "/mnt/c/Users/user/Downloads/invaders/deps/SDL_sound/src/SDL_sound_au.c" "deps/SDL_sound/CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_au.c.o" "gcc" "deps/SDL_sound/CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_au.c.o.d"
  "/mnt/c/Users/user/Downloads/invaders/deps/SDL_sound/src/SDL_sound_coreaudio.c" "deps/SDL_sound/CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_coreaudio.c.o" "gcc" "deps/SDL_sound/CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_coreaudio.c.o.d"
  "/mnt/c/Users/user/Downloads/invaders/deps/SDL_sound/src/SDL_sound_flac.c" "deps/SDL_sound/CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_flac.c.o" "gcc" "deps/SDL_sound/CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_flac.c.o.d"
  "/mnt/c/Users/user/Downloads/invaders/deps/SDL_sound/src/SDL_sound_midi.c" "deps/SDL_sound/CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_midi.c.o" "gcc" "deps/SDL_sound/CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_midi.c.o.d"
  "/mnt/c/Users/user/Downloads/invaders/deps/SDL_sound/src/SDL_sound_modplug.c" "deps/SDL_sound/CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_modplug.c.o" "gcc" "deps/SDL_sound/CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_modplug.c.o.d"
  "/mnt/c/Users/user/Downloads/invaders/deps/SDL_sound/src/SDL_sound_mp3.c" "deps/SDL_sound/CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_mp3.c.o" "gcc" "deps/SDL_sound/CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_mp3.c.o.d"
  "/mnt/c/Users/user/Downloads/invaders/deps/SDL_sound/src/SDL_sound_raw.c" "deps/SDL_sound/CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_raw.c.o" "gcc" "deps/SDL_sound/CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_raw.c.o.d"
  "/mnt/c/Users/user/Downloads/invaders/deps/SDL_sound/src/SDL_sound_shn.c" "deps/SDL_sound/CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_shn.c.o" "gcc" "deps/SDL_sound/CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_shn.c.o.d"
  "/mnt/c/Users/user/Downloads/invaders/deps/SDL_sound/src/SDL_sound_voc.c" "deps/SDL_sound/CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_voc.c.o" "gcc" "deps/SDL_sound/CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_voc.c.o.d"
  "/mnt/c/Users/user/Downloads/invaders/deps/SDL_sound/src/SDL_sound_vorbis.c" "deps/SDL_sound/CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_vorbis.c.o" "gcc" "deps/SDL_sound/CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_vorbis.c.o.d"
  "/mnt/c/Users/user/Downloads/invaders/deps/SDL_sound/src/SDL_sound_wav.c" "deps/SDL_sound/CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_wav.c.o" "gcc" "deps/SDL_sound/CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_wav.c.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
