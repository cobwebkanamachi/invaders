# Empty dependencies file for SDL3_sound-static.
# This may be replaced when dependencies are built.
