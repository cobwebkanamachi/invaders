file(REMOVE_RECURSE
  "CMakeFiles/SDL3_sound-static.dir/src/SDL_sound.c.o"
  "CMakeFiles/SDL3_sound-static.dir/src/SDL_sound.c.o.d"
  "CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_aiff.c.o"
  "CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_aiff.c.o.d"
  "CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_au.c.o"
  "CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_au.c.o.d"
  "CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_coreaudio.c.o"
  "CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_coreaudio.c.o.d"
  "CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_flac.c.o"
  "CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_flac.c.o.d"
  "CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_midi.c.o"
  "CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_midi.c.o.d"
  "CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_modplug.c.o"
  "CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_modplug.c.o.d"
  "CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_mp3.c.o"
  "CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_mp3.c.o.d"
  "CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_raw.c.o"
  "CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_raw.c.o.d"
  "CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_shn.c.o"
  "CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_shn.c.o.d"
  "CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_voc.c.o"
  "CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_voc.c.o.d"
  "CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_vorbis.c.o"
  "CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_vorbis.c.o.d"
  "CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_wav.c.o"
  "CMakeFiles/SDL3_sound-static.dir/src/SDL_sound_wav.c.o.d"
  "libSDL3_sound.a"
  "libSDL3_sound.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/SDL3_sound-static.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
