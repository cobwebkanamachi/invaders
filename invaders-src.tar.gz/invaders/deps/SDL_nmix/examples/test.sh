paplay /usr/share/sounds/alsa/Front_Center.wav
