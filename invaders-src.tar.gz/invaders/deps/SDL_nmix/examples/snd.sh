# ALSAを探しに行くのをやめさせる
export SDL_AUDIODRIVER=pulseaudio
# 通り道を改めて指定
export PULSE_SERVER=unix:/mnt/wslg/PulseServer
./1_basic
