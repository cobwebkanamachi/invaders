file(REMOVE_RECURSE
  "3_stresstest"
  "3_stresstest.pdb"
  "CMakeFiles/3_stresstest.dir/3_stresstest.c.o"
  "CMakeFiles/3_stresstest.dir/3_stresstest.c.o.d"
  "CMakeFiles/3_stresstest.dir/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix.c.o"
  "CMakeFiles/3_stresstest.dir/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix.c.o.d"
  "CMakeFiles/3_stresstest.dir/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix_file.c.o"
  "CMakeFiles/3_stresstest.dir/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix_file.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/3_stresstest.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
