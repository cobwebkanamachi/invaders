file(REMOVE_RECURSE
  "1_basic"
  "1_basic.pdb"
  "CMakeFiles/1_basic.dir/1_basic.c.o"
  "CMakeFiles/1_basic.dir/1_basic.c.o.d"
  "CMakeFiles/1_basic.dir/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix.c.o"
  "CMakeFiles/1_basic.dir/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix.c.o.d"
  "CMakeFiles/1_basic.dir/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix_file.c.o"
  "CMakeFiles/1_basic.dir/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix_file.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/1_basic.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
