file(REMOVE_RECURSE
  "CMakeFiles/test_nmix.dir/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix.c.o"
  "CMakeFiles/test_nmix.dir/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix.c.o.d"
  "CMakeFiles/test_nmix.dir/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix_file.c.o"
  "CMakeFiles/test_nmix.dir/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix_file.c.o.d"
  "CMakeFiles/test_nmix.dir/test_nmix.c.o"
  "CMakeFiles/test_nmix.dir/test_nmix.c.o.d"
  "test_nmix"
  "test_nmix.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/test_nmix.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
