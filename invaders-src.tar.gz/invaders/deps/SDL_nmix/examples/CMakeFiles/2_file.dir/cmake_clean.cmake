file(REMOVE_RECURSE
  "2_file"
  "2_file.pdb"
  "CMakeFiles/2_file.dir/2_file.c.o"
  "CMakeFiles/2_file.dir/2_file.c.o.d"
  "CMakeFiles/2_file.dir/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix.c.o"
  "CMakeFiles/2_file.dir/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix.c.o.d"
  "CMakeFiles/2_file.dir/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix_file.c.o"
  "CMakeFiles/2_file.dir/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix_file.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/2_file.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
