file(REMOVE_RECURSE
  "4_demo"
  "4_demo.pdb"
  "CMakeFiles/4_demo.dir/4_demo.c.o"
  "CMakeFiles/4_demo.dir/4_demo.c.o.d"
  "CMakeFiles/4_demo.dir/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix.c.o"
  "CMakeFiles/4_demo.dir/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix.c.o.d"
  "CMakeFiles/4_demo.dir/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix_file.c.o"
  "CMakeFiles/4_demo.dir/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix_file.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/4_demo.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
