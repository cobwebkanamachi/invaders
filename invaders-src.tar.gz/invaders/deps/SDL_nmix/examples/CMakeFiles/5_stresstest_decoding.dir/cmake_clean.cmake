file(REMOVE_RECURSE
  "5_stresstest_decoding"
  "5_stresstest_decoding.pdb"
  "CMakeFiles/5_stresstest_decoding.dir/5_stresstest_decoding.c.o"
  "CMakeFiles/5_stresstest_decoding.dir/5_stresstest_decoding.c.o.d"
  "CMakeFiles/5_stresstest_decoding.dir/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix.c.o"
  "CMakeFiles/5_stresstest_decoding.dir/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix.c.o.d"
  "CMakeFiles/5_stresstest_decoding.dir/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix_file.c.o"
  "CMakeFiles/5_stresstest_decoding.dir/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/SDL_nmix_file.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/5_stresstest_decoding.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
