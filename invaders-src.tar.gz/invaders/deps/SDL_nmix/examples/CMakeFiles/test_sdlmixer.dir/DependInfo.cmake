
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/mnt/c/Users/user/Downloads/invaders/deps/SDL_nmix/examples/test_sdlmixer.c" "CMakeFiles/test_sdlmixer.dir/test_sdlmixer.c.o" "gcc" "CMakeFiles/test_sdlmixer.dir/test_sdlmixer.c.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
