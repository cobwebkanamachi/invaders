file(REMOVE_RECURSE
  "CMakeFiles/test_sdlmixer.dir/test_sdlmixer.c.o"
  "CMakeFiles/test_sdlmixer.dir/test_sdlmixer.c.o.d"
  "test_sdlmixer"
  "test_sdlmixer.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/test_sdlmixer.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
