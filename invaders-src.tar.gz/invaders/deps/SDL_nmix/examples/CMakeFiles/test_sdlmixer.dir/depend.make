# Empty dependencies file for test_sdlmixer.
# This may be replaced when dependencies are built.
