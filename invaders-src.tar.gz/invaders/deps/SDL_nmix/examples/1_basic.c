// 1_basic.c: demonstrates how to create two simple sound sources
//            and play them simultaneously

#include <stdio.h>
#include <math.h>
#include <SDL.h>
#include "../SDL_nmix.h"

#if 1
void sine_callback(void *userdata, Uint8 *stream, int len) {
    short *buffer = (short *)stream;
    int samples = len / sizeof(short);
    double *p_x = (double *)userdata;

    for (int i = 0; i < samples; i++) {
        // float (-1.0 ~ 1.0) ではなく short (-32768 ~ 32767)
        buffer[i] = (short)(sin(*p_x) * 16384.0);
        *p_x += 0.05;
    }
}
#else
static void sine_callback(void* userdata, void* _stream, int len) {
  float* stream = (float*) _stream;
  double* x = (double*) userdata;

  float freq = 440.f;
  for (size_t i = 0; i < len / sizeof(float); i++) {
    *x += (double) 1 / 44100;
    stream[i] = sinf(freq * (*x) * 2 * M_PI);
  }
}
#endif

static inline float sign(float x) {
  if (x < 0)
    return -1;
  if (x > 0)
    return 1;
  return 0;
}

static void square_callback(void* userdata, void* _stream, int len) {
  Sint16* stream = (Sint16*) _stream;
  double* x = (double*) userdata;

  float freq = 440.f / 2;
  for (size_t i = 0; i < len / sizeof(Sint16); i += 2) {
    *x += (double) 1 / 44100;
    stream[i] = sign(sinf(freq * (*x) * 2 * M_PI)) * 5000;
    stream[i + 1] = stream[i];
  }
}

int main(int argc, char** argv) {
  if (SDL_Init(SDL_INIT_AUDIO) != 0) {
    fprintf(stderr,"SDL_Init Error: %s\n", SDL_GetError());
    return -1;
  }
  SDL_SetHint(SDL_HINT_AUDIO_DRIVER, "pulseaudio");	
  SDL_SetHint(SDL_HINT_THREAD_PRIORITY_POLICY, "0");
  if (NMIX_OpenAudio(NMIX_DEFAULT_DEVICE, NMIX_DEFAULT_FREQUENCY,
          NMIX_DEFAULT_SAMPLES) != 0) {
    fprintf(stderr, "NMIX Error: %s\n", SDL_GetError());
    return -1;
  }

  // creating a new source, with float samples, 1 channel (mono), and "x"
  // is passed as userdata.
  double x = 0;
  NMIX_Source* source1 =
      NMIX_NewSource(SDL_AUDIO_S16LE, 1, 44100, sine_callback, &x);
      //NMIX_NewSource(AUDIO_F32SYS, 1, 44100, sine_callback, &x);
  if (source1 == NULL) {
    fprintf(stderr, "NMIX Error: %s\n", SDL_GetError());
  }
  NMIX_SetPan(source1, -.2); // a bit on the left
  NMIX_SetGain(source1, .5); // 50% volume

  // creating a new stereo source with Sint16 samples
  double x2 = 0;
  NMIX_Source* source2 =
      NMIX_NewSource(SDL_AUDIO_S16LE, 2, 44100, square_callback, &x2);
      //NMIX_NewSource(AUDIO_S16SYS, 2, 44100, square_callback, &x2);
  if (source2 == NULL) {
    fprintf(stderr, "NMIX Error: %s\n", SDL_GetError());
  }
  NMIX_SetPan(source2, .9); // 90% on the right
  NMIX_SetGain(source2, .7);

  NMIX_Play(source1);
  NMIX_Play(source2);

  printf("Playing sound for 10 seconds... Press Ctrl+C to stop.\n");
  SDL_Delay(10000); // ここで10秒間、プログラムを強制的に生かし続ける
  //SDL_Delay(5 * 1000);

  NMIX_FreeSource(source1);
  NMIX_FreeSource(source2);
  NMIX_CloseAudio();
  SDL_Quit();
  return 0;
}
