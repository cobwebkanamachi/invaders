#include "SDL_nmix.h"
#include <SDL3/SDL.h>

static SDL_AudioSpec mixer = {0};
static SDL_AudioDeviceID audio_device = 0;
static SDL_AudioStream* main_stream = NULL; 
static NMIX_Source* playing_sources = NULL; 
static float master_gain = 1.f;

// 便利なクランプ関数
static SDL_INLINE float clampf(float x, float min, float max) {
  return x < min ? min : (x > max ? max : x);
}

// サンプル同士を足し合わせる
static SDL_INLINE float mix_samples(float a, float b) {
  return clampf(a + b, -1, 1);
}

// 左右の音量配分
static SDL_INLINE void apply_panning(float pan, float* left, float* right) {
  float amplitude = pan / 2 + 0.5f;
  *left *= 1.0f - amplitude;
  *right *= amplitude;
}

// --- メインミキシング・コールバック ---
// SDL3内部から「音が必要だ」と呼ばれた時に実行される
static void SDLCALL nmix_callback(void* userdata, SDL_AudioStream* stream, int additional_amount, int total_amount) {
  if (audio_device == 0 || additional_amount <= 0) return;

  // ミキシング用の一時バッファ
  float* mix_buffer = (float*)SDL_calloc(1, additional_amount);
  if (!mix_buffer) return;

  const int sample_size = sizeof(float);
  NMIX_Source* s = playing_sources;

  while (s != NULL) {
    NMIX_Source* next = s->next;
    
    // ソースからデータを吸い出す
    int avail = SDL_GetAudioStreamAvailable(s->stream);
    if (avail > 0) {
      int copy_size = (avail < additional_amount) ? avail : additional_amount;
      
      // ソースごとの一時出力バッファを確保/再利用
      if (s->out_buffer_size < copy_size) {
        s->out_buffer = SDL_realloc(s->out_buffer, copy_size);
        s->out_buffer_size = copy_size;
      }

      int bytes_read = SDL_GetAudioStreamData(s->stream, s->out_buffer, copy_size);
      
      if (bytes_read > 0) {
        float* src = (float*)s->out_buffer;
        int num_samples = bytes_read / sample_size;

        for (int i = 0; i < num_samples; i += 2) {
          if (i + 1 >= num_samples) break;
          float sl = src[i] * s->gain * master_gain;
          float sr = src[i+1] * s->gain * master_gain;
          apply_panning(s->pan, &sl, &sr);

          mix_buffer[i] = mix_samples(mix_buffer[i], sl);
          mix_buffer[i+1] = mix_samples(mix_buffer[i+1], sr);
        }
      }
    }

    // データの補充が必要かチェック
    if (SDL_GetAudioStreamAvailable(s->stream) < additional_amount && !s->eof) {
      s->callback(s->userdata, s->in_buffer, s->in_buffer_size);
      SDL_PutAudioStreamData(s->stream, s->in_buffer, s->in_buffer_size);
    }

    s = next;
  }

  // ミックスした最終結果をメインストリームに流し込む
  SDL_PutAudioStreamData(main_stream, mix_buffer, additional_amount);
  SDL_free(mix_buffer);
}

int NMIX_OpenAudio(const char* device, int rate, int samples) {
  if (audio_device != 0) return -1;
  if (!SDL_WasInit(SDL_INIT_AUDIO)) SDL_InitSubSystem(SDL_INIT_AUDIO);

  SDL_AudioSpec wanted = { SDL_AUDIO_F32, 2, (rate > 0) ? rate : 44100 };
  audio_device = SDL_OpenAudioDevice(SDL_AUDIO_DEVICE_DEFAULT_PLAYBACK, &wanted);
  if (audio_device == 0) return -1;

  SDL_GetAudioDeviceFormat(audio_device, &mixer, NULL);

  // 重要：デバイスと1対1で結ばれる「唯一の」ストリーム
  main_stream = SDL_CreateAudioStream(&mixer, &mixer);
  if (main_stream) {
    // コールバックを登録：SDL3が自動で呼んでくれる
    SDL_SetAudioStreamGetCallback(main_stream, nmix_callback, NULL);
    SDL_BindAudioStream(audio_device, main_stream);
  }

  SDL_ResumeAudioDevice(audio_device);
  return 0;
}

int NMIX_CloseAudio(void) {
  if (audio_device == 0) return -1;
  SDL_PauseAudioDevice(audio_device);
  if (main_stream) {
    SDL_UnbindAudioStream(main_stream);
    SDL_DestroyAudioStream(main_stream);
    main_stream = NULL;
  }
  SDL_CloseAudioDevice(audio_device);
  audio_device = 0;
  return 0;
}

NMIX_Source* NMIX_NewSource(SDL_AudioFormat format, Uint8 channels, int rate,
    NMIX_SourceCallback callback, void* userdata) {
  if (audio_device == 0) return NULL;

  NMIX_Source* source = SDL_calloc(1, sizeof(NMIX_Source));
  if (!source) return NULL;

  source->format = format;
  source->channels = channels;
  source->rate = rate;
  source->gain = 1.f;
  source->callback = callback;
  source->userdata = userdata;

  int in_nb_samples = (source->rate / 10) + 1;
  source->in_buffer_size = in_nb_samples * source->channels * SDL_AUDIO_BYTESIZE(source->format);
  source->in_buffer = SDL_malloc(source->in_buffer_size);
  
  // ソース個別のストリーム作成 (バインドは絶対にしない)
  SDL_AudioSpec src_spec = { source->format, source->channels, source->rate };
  SDL_AudioSpec dst_spec = { mixer.format, mixer.channels, mixer.freq };
  source->stream = SDL_CreateAudioStream(&src_spec, &dst_spec);

  return source;
}

void NMIX_FreeSource(NMIX_Source* source) {
  if (!source) return;
  if (NMIX_IsPlaying(source)) NMIX_Pause(source);
  if (source->stream) SDL_DestroyAudioStream(source->stream);
  if (source->in_buffer) SDL_free(source->in_buffer);
  if (source->out_buffer) SDL_free(source->out_buffer);
  SDL_free(source);
}

int NMIX_Play(NMIX_Source* source) {
  if (!source || NMIX_IsPlaying(source)) return -1;
  source->eof = false;
  if (!playing_sources) {
    playing_sources = source;
  } else {
    NMIX_Source* v = playing_sources;
    while (v->next) v = v->next;
    v->next = source;
    source->prev = v;
  }
  return 0;
}

void NMIX_Pause(NMIX_Source* source) {
  if (!source || !NMIX_IsPlaying(source)) return;
  if (source->next) source->next->prev = source->prev;
  if (source->prev) source->prev->next = source->next;
  else playing_sources = source->next;
  source->prev = NULL;
  source->next = NULL;
}

bool NMIX_IsPlaying(NMIX_Source* source) {
  return (source != NULL && (source == playing_sources || source->prev != NULL));
}

// ユーティリティ系
void NMIX_PausePlayback(bool pause_on) { if (audio_device) { if (pause_on) SDL_PauseAudioDevice(audio_device); else SDL_ResumeAudioDevice(audio_device); } }
float NMIX_GetMasterGain(void) { return master_gain; }
void NMIX_SetMasterGain(float gain) { master_gain = clampf(gain, 0, 2); }
SDL_AudioSpec* NMIX_GetAudioSpec(void) { return &mixer; }
SDL_AudioDeviceID NMIX_GetAudioDevice(void) { return audio_device; }
float NMIX_GetPan(NMIX_Source* source) { return source ? source->pan : 0; }
void NMIX_SetPan(NMIX_Source* source, float pan) { if (source) source->pan = clampf(pan, -1, 1); }
float NMIX_GetGain(NMIX_Source* source) { return source ? source->gain : 0; }
void NMIX_SetGain(NMIX_Source* source, float gain) { if (source) source->gain = clampf(gain, 0, 2); }
